package Sumergibles;
public class Submarino implements Sumergible {
	    private double profundidadMaxima;
	    private double profundidadActual;
	    public Submarino(double profundidadMaxima) {
	        this.profundidadMaxima = profundidadMaxima;
	        this.profundidadActual = 0; // empieza en la superficie
	    }
	    public double getProfundidadMaxima() {
	        return profundidadMaxima;
	    }
	    public double getProfundidadActual() {
	        return profundidadActual;
	    }
	    public void sumergir(double metros) {
	        if (profundidadActual + metros > profundidadMaxima) {
	            System.out.println("¡No se puede! Supera la profundidad máxima (" + profundidadMaxima + " m).");
	        } else {
	            profundidadActual += metros;
	            System.out.println("Submarino sumergido a " + profundidadActual + " metros.");
	        }
	    }
	    public void ascender(double metros) {
	        if (profundidadActual - metros < 0) {
	            profundidadActual = 0;
	            System.out.println("El submarino está en la superficie.");
	        } else {
	            profundidadActual -= metros;
	            System.out.println("El submarino ascendió a " + profundidadActual + " metros.");
	        }
	    }
	}