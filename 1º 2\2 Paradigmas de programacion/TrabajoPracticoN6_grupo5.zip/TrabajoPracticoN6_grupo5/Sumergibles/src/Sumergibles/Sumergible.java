package Sumergibles;

	public interface Sumergible {
	    double getProfundidadMaxima();
	    double getProfundidadActual();
	    void sumergir(double metros);
	    void ascender(double metros);
	}

