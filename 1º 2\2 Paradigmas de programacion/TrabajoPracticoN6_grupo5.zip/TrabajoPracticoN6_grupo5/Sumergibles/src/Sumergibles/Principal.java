package Sumergibles;
	public class Principal {
	    public static void main(String[] args) {
	        Submarino s = new Submarino(300); // profundidad máxima = 300 m

	        System.out.println("Profundidad máxima: " + s.getProfundidadMaxima() + " metros");
	        // Submarino 1
	        System.out.println("=== Submarino 1 ===");
	        s.sumergir(100);
	        s.sumergir(250);  // debería avisar que no puede sumergirse
	        s.ascender(50);
	        s.ascender(200);  // debería volver a la superficie
	        Submarino s2 = new Submarino(150);
	        Submarino s3 = new Submarino(220);

	        // Submarino 2
	        System.out.println("\n=== Submarino 2 ===");
	        s2.sumergir(149);
	        s2.ascender(10);
	        s2.sumergir(200); // no debería poder sumergirse
	        s2.ascender(100);

	        // Submarino 3
	        System.out.println("\n=== Submarino 3 ===");
	        s3.sumergir(200);
	        s3.ascender(150);
	        s3.ascender(80);
	        s3.sumergir(450); // no debería poder sumergirse
	    }
	}
