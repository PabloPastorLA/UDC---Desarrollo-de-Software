package Vehiculos;

public class Autos extends Automoviles {
    public Autos(String marca, String modelo, String patente, double valor, int anioFabricacion, Propietario propietario) {
        super(marca, modelo, patente, valor, anioFabricacion, propietario);
    }


    public double CalcularImpuesto(int anioActual) {
    	//llamamos al metodo de la superclase/ clase padre (Automoviles)
        return super.CalcularImpuesto(anioActual); 
    }
}
