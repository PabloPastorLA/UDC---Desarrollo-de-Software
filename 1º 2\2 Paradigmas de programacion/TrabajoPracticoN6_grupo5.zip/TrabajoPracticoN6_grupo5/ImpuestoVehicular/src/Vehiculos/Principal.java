package Vehiculos;
//Clase principal
public class Principal {
	public static void main(String[] args) {
        int anioActual = 2025;
        //creamos un array con tamaño de 6, para guardar cada vehiculo
        Vehiculos[] flota = new Vehiculos[6];
        flota[0] = new Camiones("Fiat", "15000", "FRE 123", 150000, 1990, new Propietario("Expreso Morresi", "Echeverria 432"));
        flota[1] = new Camiones("Volvo", "324", "GUL 812", 234000, 2007, new Propietario("Transportes Ruben", "Yapeyu 678"));
        flota[2] = new Aviones("Boeing", "727", "DFXCVBERT", 12000000, 1993, new Propietario("Aerolíneas Pluma", "Belgrano 12"));
        flota[3] = new Autos("VW Passat", "JMH 234", "2010", 120000, 2010, new Propietario("Aerolíneas Pluma", "Belgrano 12"));
        flota[4] = new Autos("VW Golf", "FFD 321", "2005", 28000, 2005, new Propietario("Juan Perez", "Rondeau 432"));
        flota[5] = new Lanchas("Cuto", "345", "FHUTYR", 15000, 2000, new Propietario("Juan Perez", "Rondeau 432"));
  
        double totalImpuestos = 0;
        //Recorremos y calculamos los impuestos
        for (Vehiculos v : flota) {
            double impuesto = v.CalcularImpuesto(anioActual);
            System.out.println(
                    v.getClass().getSimpleName() + " - " +
                    v.marca + " " + v.modelo + " - Propietario: " +
                    v.propietario.getNombre() + " - Direccion: " +
                    v.propietario.getDomicilio() + " - Impuesto: $" + impuesto
                );

                totalImpuestos += impuesto;
            }
            // Mostramos el total de los impuestos
            System.out.println("Valor total de los impuestos de la flota: $" + totalImpuestos);
        }
    }
