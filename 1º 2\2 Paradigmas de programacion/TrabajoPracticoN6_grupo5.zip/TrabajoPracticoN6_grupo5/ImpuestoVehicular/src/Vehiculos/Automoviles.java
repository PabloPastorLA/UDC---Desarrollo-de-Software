package Vehiculos;
//Clase abstracta que hereda de Vehiculos
/////////////////////////////////////////////AUTOMOVILES
abstract class Automoviles extends Vehiculos {
	private static final double INDICE = 0.012;

	public Automoviles(String marca, String modelo, String patente, double valor, int anioFabricacion,
			Propietario propietario) {
		super(marca, modelo, patente, valor, anioFabricacion, propietario);
	}
	//Calculamos el impuesto segun los años de antiguedad
	public double CalcularImpuesto(int anioActual) {
		int antiguedad = getAntiguedad(anioActual);
		if (antiguedad > 30) { //Si tiene mas de 30, no paga impuestos
			System.out.println("Usted no paga impuestos.");
			return 0;
		} else {
			return (1.5 - (antiguedad / 30.0)) * INDICE * (valor / 10.0);
		}
	}

}
/////////////////////////////////////////////////CAMIONES
class Camiones extends Vehiculos {
    private static final double INDICE = 0.012;

    public Camiones(String marca, String modelo, String patente, double valor, int anioFabricacion, Propietario propietario) {
        super(marca, modelo, patente, valor, anioFabricacion, propietario);
    }


    public double CalcularImpuesto(int anioActual) {
        int antiguedad = getAntiguedad(anioActual);
        if (antiguedad > 30) {
            System.out.println("Usted no paga impuestos.");
            return 0;
        } else {
            return (1.5 - (antiguedad / 30.0)) * INDICE * (valor / 10.0);
        }
    
}


}
//////////////////////////////////////////////////////////LANCHAS
class Lanchas extends Vehiculos {
    private static final double INDICE = 0.012;

    public Lanchas(String marca, String modelo, String patente, double valor, int anioFabricacion, Propietario propietario) {
        super(marca, modelo, patente, valor, anioFabricacion, propietario);
    }
    public double CalcularImpuesto(int anioActual) {
        return INDICE * valor;
    }


}
////////////////////////////////////////////////////////AVIONES

class Aviones extends Vehiculos {
	private static final double INDICE = 0.0015;

	public Aviones(String marca, String modelo, String patente, double valor, int anioFabricacion,
			Propietario propietario) {
		super(marca, modelo, patente, valor, anioFabricacion, propietario);
	}

	public double CalcularImpuesto(int anioActual) {
		int antiguedad = getAntiguedad(anioActual);
		return antiguedad * INDICE * (valor / 100.0);
	}


}

//////////////////////////////////////////
