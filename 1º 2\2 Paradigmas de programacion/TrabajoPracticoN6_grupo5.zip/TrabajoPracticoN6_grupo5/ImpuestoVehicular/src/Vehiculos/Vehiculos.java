package Vehiculos;

abstract class Vehiculos {
	protected String marca;
	protected String modelo;
	protected String patente;
	protected double valor;
	protected int anioFabricacion;
	protected Propietario propietario;

	// constructor de vehiculos
	public Vehiculos (String marca, String modelo, String patente,double valor, int anioFabricacion,Propietario propietario) {
			this.marca = marca;
			this.modelo = modelo;
			this.patente = patente;
			this.valor = valor;
			this.anioFabricacion = anioFabricacion;
			this.propietario = propietario;
	}
	//Metodo para calcular su antiguedad
	public int getAntiguedad(int anioActual) {
        return anioActual - anioFabricacion;
    }
	
	public abstract double CalcularImpuesto(int anioActual);

}
