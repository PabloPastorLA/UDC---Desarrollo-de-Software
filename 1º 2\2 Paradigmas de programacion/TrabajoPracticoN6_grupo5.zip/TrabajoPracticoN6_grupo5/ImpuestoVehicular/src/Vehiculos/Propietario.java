package Vehiculos;
//Clase propietario para guardar los datos de los dueños de los vehiculos
public class Propietario {
	private String nombre;
	private String domicilio;

	public Propietario(String nombre, String domicilio) {
		this.nombre = nombre;
		this.domicilio = domicilio;
	}

	// Método para obtener el nombre
    public String getNombre() {
        return nombre;
    }

    // Método para obtener la dirección
    public String getDomicilio() {
        return domicilio;
    }
}
