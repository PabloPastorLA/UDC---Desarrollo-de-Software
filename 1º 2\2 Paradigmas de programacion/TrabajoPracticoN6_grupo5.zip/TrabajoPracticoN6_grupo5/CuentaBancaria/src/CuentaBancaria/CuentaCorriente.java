package CuentaBancaria;


//Creamos la subclase cajaDeAhorro
public class CuentaCorriente extends CuentaBancaria {
	   private static double tasaInteresAnual = 0.08; 
	   private static final double COSTO_MENSUAL = 52.37;
	   private double descubiertoMax;
	   
	   
	   public CuentaCorriente (double saldoInicial, double descubiertoMax) {
		   super (saldoInicial,COSTO_MENSUAL);
		   this.descubiertoMax = descubiertoMax;
		  
	   }
	   public void extraer(double monto) {
	        if (monto <= saldo + descubiertoMax) {
	            saldo -= monto;
	        } else {
	            System.out.println("Fondos insuficientes!");
	        }
	    }
	   public double getCostoMensual() {
	        return COSTO_MENSUAL;
	    }
	    public double getTasaInteres() {
	        return tasaInteresAnual;
	    }
	    public double getDescubiertoMax() {
	        return descubiertoMax;
	    }
	    //modificaciones
	    public static void modificarTasaInteres(double nuevaTasa) {
	        tasaInteresAnual = nuevaTasa;
	        System.out.println("Tasa de interés : " + tasaInteresAnual);
	    }
	    public void modificarDescubierto(double nuevoDescubierto) {
	        this.descubiertoMax = nuevoDescubierto;
	        System.out.println("Descubierto máximo : " + descubiertoMax);
	    }
	    
}
