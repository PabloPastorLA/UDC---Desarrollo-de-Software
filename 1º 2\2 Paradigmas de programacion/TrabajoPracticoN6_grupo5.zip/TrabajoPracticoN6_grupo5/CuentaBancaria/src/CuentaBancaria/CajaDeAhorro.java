package CuentaBancaria;


//Creamos la subclase cajaDeAhorro
public class CajaDeAhorro extends CuentaBancaria {
	   private static double tasaInteresAnual = 0.06; 
	   private static final double COSTO_MENSUAL = 32.24;
	
	   //constructor
	   public CajaDeAhorro(double saldoInicial) {
	       super(saldoInicial, COSTO_MENSUAL); //llama al constructor de la clase padre
	    }
	    public void extraer(double monto) {
	    	if (monto <= saldo) {
	            saldo -= monto;
	            System.out.println("Extraccion realizada. Saldo actual: " + saldo);
	        } else {
	            System.out.println("Fondos insuficientes.");
	        }
	    }
	    public double getCostoMensual() {
	        return COSTO_MENSUAL;
	    }
	    public double getTasaInteres() {
	        return tasaInteresAnual;
	    }

	    public static void modificarTasaInteres(double nuevaTasa) {
	        tasaInteresAnual = nuevaTasa;
	    }
	    
	}

