package CuentaBancaria;

public abstract class CuentaBancaria {
	protected double saldo;
	protected double costoMensual;

//constructor
public CuentaBancaria (double saldoInicial, double costoMensual) {
		this.saldo = saldoInicial;
		this.costoMensual = costoMensual;
}

//metodos que usan las subclases
public abstract void extraer(double monto);
public abstract double getTasaInteres();
public abstract double getCostoMensual();

//metodo depositar, Si el monto es mayor a 0, que lo sume al saldo .
public void depositar (double monto) {
	if (monto > 0) {
		saldo += monto;
		System.out.println ("Depositado correctamente. Saldo actual: "+ saldo);
	} else{
		System.out.println ("Ingrese un monto mayor a 0.");
	}
}
public void consultarSaldo() {
    System.out.println("Saldo actual: " + saldo);
}

		
}
