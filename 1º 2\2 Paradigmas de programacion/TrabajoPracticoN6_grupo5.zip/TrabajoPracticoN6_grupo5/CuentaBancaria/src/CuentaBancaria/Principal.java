package CuentaBancaria;

public class Principal{
	public static void main(String[] args) {
        CajaDeAhorro ca = new CajaDeAhorro(6000);
        CuentaCorriente cc = new CuentaCorriente(30000, 80000);	
	
     //pruebas
        System.out.println("----------------Caja de Ahorro------------");
        ca.consultarSaldo();
        ca.extraer(3000);
        ca.consultarSaldo();
        ca.depositar(10000);
        ca.consultarSaldo();
       
        System.out.println("---------------Cuenta Corriente-----------");
        cc.extraer(10000); 
        cc.consultarSaldo();
        cc.depositar(23000);
        cc.consultarSaldo();
        System.out.println("------------------------------------------");
        
        System.out.println("------Modificaciones tasa de interes------");
     // Modificamos descubierto y tasa de interés
        cc.modificarDescubierto(100000);
        CuentaCorriente.modificarTasaInteres(0.5);
        CajaDeAhorro.modificarTasaInteres(0.04);
        System.out.println("DESCUBIERTO Cuenta Corriente: " + cc.getDescubiertoMax());
        System.out.println("TASA Cuenta Ahorro: " + ca.getTasaInteres());
        System.out.println("TASA Cuenta Corriente: " + cc.getTasaInteres());
        
    }
	
}