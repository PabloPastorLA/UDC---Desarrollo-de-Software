package astros;

import java.util.List;

public interface AstroCentral {
	public void addAstroSecundario(Astro astro);
	public List<Astro> getAstrosSecundarios();
	
}
